<html>
	<head>
		<title>PHP Test</title>
	</head>
	<body>
		<p>
			January 12, 2017
		</p>
		<?php
			//Print today's date in the format mm/dd/yy
			print(date("m.d.y"));
			
			echo "</br></br>Brandon Ellis";
		?>
	</body>
</html>
	